<?php
/**
 * @package Joostina BOSS
 * @copyright Авторские права (C) 2008-2010 Joostina team. Все права защищены.
 * @license Лицензия http://www.gnu.org/licenses/gpl-2.0.htm GNU/GPL, или help/license.php
 * Joostina BOSS - свободное программное обеспечение распространяемое по условиям лицензии GNU/GPL
 * Joostina BOSS основан на разработках Jdirectory от Thomas Papin
 */
defined('_VALID_MOS') or die();

class HTML_loginza {

    public static function configuration($secretkey, $vidgetid) {
?>
        <form action="index2.php" method="post" name="adminForm" id="adminForm">

    <? if ($secretkey == '123' or $secretkey == null): ?>
            <div style="color: #fff; font-size: 10pt; font-weight: bold; padding: 15px; border: 1px solid #bf0707; background: #ff7171;">
        <?php echo ATTENTIONKEY; ?>
        </div>
    <? endif; ?>
            <div style="padding: 15px 15px 0 15px; font-size: 9pt; text-align: center;">
                <p><?php echo INSYRUCT; ?></p>
            </div>
            <div style="text-align: center;">
                <label><?php echo LOGINZA_SKEY; ?></label>
                <input type="text" name="secret" size="50" value="<?php echo $secretkey; ?>" />
                <label><?php echo LOGINZA_VIDGETID; ?></label>
                <input type="text" name="vidgetid" size="50" value="<?php echo $vidgetid; ?>" /> <br />
                <input type="submit" value="<?php echo LOGINZA_SAVE; ?>" class="button">
            </div>
            
            <div style="text-align: center; padding: 15px; font-size: 9pt; ">
                <p><?php echo DESC; ?></p>

                <p><?php echo PROVIDERSAUTH; ?><br><br>
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/yandex.png"> Yandex,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/vkontakte.png"> VKontakte,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/facebook.png"> Facebook,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/twitter.png"> Twitter,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/loginza.png"> Loginza,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/myopenid.png"> MyOpenID,<br/>
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/google.png"> Google,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/flickr.png"> Flickr,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/mailru.png"> Mail.Ru,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/rambler.png"> Rambler,
                    <img src="<? echo JPATH_SITE; ?>/administrator/components/com_loginza/img/webmoney.png"> Webmoney,
                    AOL, VeriSign.</p>
            </div>
            <div style="padding: 15px; text-align: center;">
                <h3><?php echo AUTHORS; ?></h3>
                <ul>
                    <li style="list-style:none; font-size: 10pt;"><a href="http://a-piskunov.ru" target="_blank">Антон Пискунов</a></li>
                    <li style="list-style:none; font-size: 10pt;"><a href="http://vjoomla.ru" target="_blank">vjoomla.ru</a></li>
                </ul>
                <h3><?php echo BUYBEER; ?></h3>
                <ul>
                    <li style="list-style:none; font-size: 10pt;">WMR: R121569261507</li>
                    <li style="list-style:none; font-size: 10pt;">WMZ: Z261851150418</li>
                    <li style="list-style:none; font-size: 10pt;"><?php echo YAR; ?> 41001494329417</li>
                </ul>
            </div>
            <div style="padding: 15px; font-size: 9pt; text-align: center;">
        <?php echo HOMEPAGE; ?> <a href="http://vjoomla.ru/blogs/item/277-loginza.html">www.vjoomla.ru</a><br>
            <a href="http://vjoomla.ru/blogs/item/277-loginza.html"><?php echo INSTRUCTION; ?></a>
        </div>
        <input type="hidden" name="option" value="com_loginza" />
        <input type="hidden" name="act" value="configuration" />
        <input type="hidden" name="task" value="save" />
    </form>
<?php
        }

        public static function sort($title, $order, $direction = 'asc', $selected = 0) {
            $direction = strtolower($direction);
            $images = array('sort_asc.png', 'sort_desc.png');
            $index = intval($direction == 'desc');
            $direction = ($direction == 'desc') ? 'asc' : 'desc';
            $task = JPATH_SITE.'/administrator/index2.php';
            
            $html = '<a href="javascript:tableOrdering(\'' . $order . '\',\'' . $direction . '\',\'' . $task . '\');" title="Click to sort this column">';
            $html .= $title;
            if ($order == $selected) {
                $html .= '<img src="' . JPATH_SITE . '/administrator/templates/joostfree/images/ico/' . $images[$index] . '" />';
            }
            $html .= '</a>';
            return $html;
        }

        public static function tableUsers($items, $lists, $string, $pagination) {
?>
            <table class="adminlist" cellpadding="1">
                <thead>
                    <tr>
            <th width="2%" class="title">
                <?php echo '№'; ?>
            </th>
            <th width="3%" class="title">
                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($items); ?>);" />
            </th>
            <th class="title">
                <?php echo self::sort('Name', 'a.name', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
            <th width="15%" class="title" >
                <?php echo self::sort('Username', 'a.username', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
            <th width="5%" class="title" nowrap="nowrap">
                <?php echo 'Logged In'; ?>
            </th>
            <th width="15%" class="title">
                <?php echo self::sort('Group', 'groupname', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
            <th width="15%" class="title">
                <?php echo self::sort('E-Mail', 'a.email', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
            <th width="10%" class="title">
                <?php echo self::sort('Last Visit', 'a.lastvisitDate', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
            <th width="1%" class="title" nowrap="nowrap">
                <?php echo self::sort('ID', 'a.id', @$lists['order_Dir'], @$lists['order']); ?>
            </th>
        </tr>
    </thead>
    <tfoot>
        <tr>
            <td colspan="10">
        <?php echo $pagination->getListFooter(); ?>
            </td>
        </tr>
    </tfoot>
    <tbody>
<?php
                $k = 0;
                for ($i = 0, $n = count($items); $i < $n; $i++) {
                    $row = & $items[$i];

                    $img = $row->block ? 'publish_x.png' : 'tick.png';
                    $task = $row->block ? 'unblock' : 'block';
                    $alt = $row->block ? 'Enabled' : 'Blocked';
                    $link = 'index.php?option=com_users&amp;view=user&amp;task=edit&amp;cid[]=' . $row->id . '';

                    if ($row->lastvisitDate == "0000-00-00 00:00:00") {
                        $lvisit = 'Never';
                    } else {
                        $lvisit = $row->lastvisitDate; //strftime('%Y-%m-%d %H:%M:%S', $row->lastvisitDate);
                    }

                    //Отделяем нужные постфиксы username для вывода по категориям
                    if (preg_match($string, $row->username)) {
?>
                        <tr class="<?php echo "row$k"; ?>">
                            <td>
        <?php echo $i + 1 + $pagination->limitstart; ?>
                            </td>
                            <td>
                <?php echo '<input type="checkbox" id="cb'.$i.'" name="cid[]" value="'.$row->id.'" onclick="isChecked(this.checked);" />'; ?>
                    </td>
                    <td>
                        <a href="<?php echo $link; ?>">
                            <?php echo $row->name; ?>
                        </a>
                    </td>
                    <td>
                    <?php echo $row->username; ?>
                </td>
                <td align="center">
                <?php echo $row->loggedin ? '<img src="images/tick.png" width="16" height="16" border="0" alt="" />' : ''; ?>
                    </td>
                    <td>
                        <?php echo $row->groupname; ?>
                    </td>
                    <td>
                        <a href="mailto:<?php echo $row->email; ?>">
                            <?php echo $row->email; ?>
                        </a>
                    </td>
                    <td nowrap="nowrap">
                    <?php echo $lvisit; ?>
                </td>
                <td>
                <?php echo $row->id; ?>
                    </td>
                </tr>
                <?php
                        $k = 1 - $k;
                    }
                }
                ?>
            </tbody>
        </table>
        <?php
            }

            public static function listUsers($items, $lists, $secretkey, $pagination) {
        ?>
<script language="javascript" type="text/javascript">
function tableOrdering( order, dir, task )
{
	var form = document.adminForm;

	form.filter_order.value	 = order;
	form.filter_order_Dir.value	= dir;
	document.adminForm.submit( task );
}
</script>
                <form action="index2.php" method="post" name="adminForm" id="adminForm">
<? if ($secretkey == '123' or $secretkey == null): ?>
                    <div style="color: #fff; font-size: 10pt; font-weight: bold; padding: 15px; border: 1px solid #bf0707; background: #ff7171;">
<?php echo ATTENTIONKEY; ?>
                    </div>
<? endif; ?>

                    <div style="padding: 15px;">
<?
                    $pane = new mosTabs(0, 1);
                    $pane->startPane('pane');
                    $pane->startTab('Google', 'slider1');


                    self::tableUsers($items, $lists, "/\:google/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('Яндекс', 'slider2');

                    self::tableUsers($items, $lists, "/\:yandex/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('Mail.ru', 'slider3');

                    self::tableUsers($items, $lists, "/\:mailru/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('ВКонтакте', 'slider4');

                    self::tableUsers($items, $lists, "/\:vkontakte/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('Facebook', 'slider5');

                    self::tableUsers($items, $lists, "/\:facebook/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('Twitter', 'slider6');

                    self::tableUsers($items, $lists, "/\:twitter/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('Loginza', 'slider7');

                    self::tableUsers($items, $lists, "/\:loginza/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('myOpenID', 'slider8');

                    self::tableUsers($items, $lists, "/\:myopenid/i", $pagination);

                    $pane->endTab();
                    $pane->startTab('WebMoney', 'slider9');

                    self::tableUsers($items, $lists, "/\:webmoney/i", $pagination);

                    $pane->endTab();
                    $pane->endPane();
?>
                </div>

                <input type="hidden" name="option" value="com_loginza" />
                <input type="hidden" name="act" value="" />
                <input type="hidden" name="task" value="" />
                <input type="hidden" name="boxchecked" value="0" />
                <input type="hidden" name="filter_order" value="<?php echo $lists['order']; ?>" />
                <input type="hidden" name="filter_order_Dir" value="<?php echo $lists['order_Dir']; ?>" />
                <input type="hidden" name="<?php echo josSpoofValue(); ?>" value="1" />
                </form>
<?php
                }

            }
?>