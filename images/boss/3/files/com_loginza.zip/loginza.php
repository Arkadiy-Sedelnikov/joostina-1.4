<?php
/*
 * @version		1.0.7
 * @package		Joomla
 * @subpackage	Loginza
 * @copyright	Copyright (C) 2010 Piskunov Anton. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @url 		www.a-piskunov.ru
 *
 * Component Loginza is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined( '_VALID_MOS' ) or die();

require_once( $mainframe->getPath( 'class' ) );

//Креате зе нью контроллер
$controller = new LoginzaController();

//Запрос с токеном. Обратно - json
$json = $controller->request(@$_POST['token']);

//Входим!
$controller->auth($json);
?>