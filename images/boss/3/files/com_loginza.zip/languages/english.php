<?php
defined( '_VALID_MOS' ) or die();

//General
DEFINE( "ATTENTIONKEY", "Enter the secret key before using the component! The secret key is an arbitrary combination of the Latin alphabet, numbers and symbols. The secret key is involved in the process of generating passwords." );
DEFINE( "DESC", "This feature allows you to use for authentication accounts popular portals (Yandex, Google, Rambler, Mail.Ru, LiveJournal, etc)., Social networks Vkontakte and Facebook, as well as OpenID identifiers" );
DEFINE( "PROVIDERSAUTH", "The following authentication providers:" );
DEFINE( "AUTHORS", "Authors:" );
DEFINE( "YAR", "Yandex.Money:" );
DEFINE( "BUYBEER", "Buy a beer to the developers! :)" );
DEFINE( "HOMEPAGE", "Homepage:" );
DEFINE( "INSTRUCTION", "Instructions for configuring" );
DEFINE( "LOGINZA_CONFIGURATION_SAVED", "CONFIGURATION SAVED" );
DEFINE( "LOGINZA_SAVE", "SAVE" );
DEFINE( "LOGINZA_SKEY", "Secret key" );
?>