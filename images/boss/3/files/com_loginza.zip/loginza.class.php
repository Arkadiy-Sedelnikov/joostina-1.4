<?php

/*
 * @version		1.0.7
 * @package		Joomla
 * @subpackage	Loginza
 * @copyright	Copyright (C) 2010 Piskunov Anton. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * @url 		www.a-piskunov.ru
 *
 * Component Loginza is free software. This version may have been modified pursuant to the
 * GNU General Public License, and as distributed it includes or is derivative
 * of works licensed under the GNU General Public License or other free or open
 * source software licenses. See COPYRIGHT.php for copyright notices and
 * details.
 */

defined('_VALID_MOS') or die();

class loginzaAdmin extends mosDBTable {
    var $group = 'com_loginza';
    var $subgroup = '';
    var $name = null;
    var $value = null;

    function __construct() {
        $db = database::getInstance();
        $this->mosDBTable('#__config', 'id', $db);
    }

    function __destruct() {
        
    }
}

class LoginzaController {

   public function request($token)
    {
        $json = array();
        $database = database::getInstance();
        $q = "SELECT `name`, `value` FROM #__config WHERE `group` = 'com_loginza'";
        $params = $database->setQuery($q)->loadObjectList('name');

        $secret = (!@$params['secret']->value) ? '' : $params['secret']->value;
        $widget = (!@$params['vidgetid']->value) ? '' : $params['vidgetid']->value;
        $sieg = md5($token . $secret);

        $file = file("http://loginza.ru/api/authinfo?token=" . $token . "&id=" . $widget . "&sig=" . $sieg);

        if ($file){
            $json = json_decode($file[0], true);
            if(isset($json['error_type'])){
                $json = array();
            }
        }
        return $json;
    }

 private function generatePasswd($json) {
        $database = database::getInstance();
        $q = "SELECT `value` FROM #__config WHERE `group` = 'com_loginza' AND `name` = 'secret'";
        $secretkey = $database->setQuery($q, 0, 1)->loadResult();
        $secretkey = (!$secretkey) ? '' : $secretkey;

        $passwd = $json['identity'] . $secretkey;

        return $passwd;
    }

    private function getNameProvider($json) {
        
        if (!isset ($json['provider']))
            return FALSE;
        
        //Google
        if (preg_match("/https:\/\/www.google.com\/accounts/i", $json['provider'])) {
            $nameProvider = "google";
        }
        //Yandex.ru
        if ($json['provider'] == 'http://openid.yandex.ru/server/') {
            $nameProvider = "yandex";
        }
        //Mail.ru
        if ($json['provider'] == 'http://mail.ru/') {
            $nameProvider = "mailru";
        }
        //VKontakte
        if ($json['provider'] == 'http://vkontakte.ru/') {
            $nameProvider = "vkontakte";
        }
        //Facebook
        if ($json['provider'] == 'http://www.facebook.com/') {
            $nameProvider = "facebook";
        }
        //Twitter.ru
        if ($json['provider'] == 'http://twitter.com/') {
            $nameProvider = "twitter";
        }
        //Loginza
        if ($json['provider'] == 'https://loginza.ru/server/') {
            $nameProvider = "loginza";
        }
        //MyOpenId
        if ($json['provider'] == 'http://www.myopenid.com/server') {
            $nameProvider = "myopenid";
        }
        //Web-money
        preg_match("/^(https:\/\/)?([^\/]+)?(wmkeeper.com)/", $json['identity'], $matches);
        $webmoneyProvider = @$matches[3];
        if ($webmoneyProvider == 'wmkeeper.com') {
            $nameProvider = "webmoney";
        }
        //Rambler
        if ($json['provider'] == 'http://id.rambler.ru/script/openid.cgi') {
            $nameProvider = "rambler";
        }
        //Flickr
        if ($json['provider'] == 'https://open.login.yahooapis.com/openid/op/auth') {
            $nameProvider = "flickr";
        }

        return $nameProvider;
    }

    private function getId($json) {
        $nameProvider = $this->getNameProvider($json);
    
        if(!$nameProvider)
            return FALSE;

        //Google
        if ($nameProvider == "google") {
            preg_match("/^(https:\/\/www.google.com\/accounts\/o8\/id\?id=)?([^\/]+)/", $json['identity'], $matches);
            echo $id = $matches[2];
        }
        //Yandex.ru
        if ($nameProvider == "yandex") {
            preg_match("/^(http:\/\/openid.yandex.ru\/)?([^\/]+)/", $json['identity'], $matches);
            $id = $matches[2];

            if ($id == 'http:') {
                preg_match("/^(http:\/\/?([^\/]+).ya.ru)/", $json['identity'], $matches);
                $id = $matches[2];
            }
        }
        //Mail.ru
        if ($nameProvider == "mailru") {
            preg_match("/^(http:\/\/my.mail.ru\/mail\/)?([^\/]+)/", $json['identity'], $matches);
            $id = $matches[2];
        }
        //VKontakte
        if ($nameProvider == "vkontakte") {
            preg_match("/^(http:\/\/vkontakte.ru\/)?([^\/]+)/", $json['identity'], $matches);
            $id = $matches[2];
        }
        //Facebook
        if ($nameProvider == "facebook") {
            preg_match("/^(http:\/\/www.facebook.com\/profile\.php\?id=)?([^\/]+)/", $json['identity'], $matches);
            $id = mb_strtolower($matches[2]);
        }
        //Twitter.ru
        if ($nameProvider == "twitter") {
            preg_match("/^(http:\/\/twitter.com\/)?([^\/]+)/", $json['identity'], $matches);
            $id = mb_strtolower($matches[2]);
        }
        //Loginza
        if ($nameProvider == "loginza") {
            preg_match("/^(http:\/\/)?([^\/]+)?(\.loginza\.ru)/", $json['identity'], $matches);
            $id = mb_strtolower($matches[2]);
        }
        //MyOpenId
        if ($nameProvider == "myopenid") {
            preg_match("/^(http:\/\/?([^\/]+).myopenid.com)/", $json['identity'], $matches);
            $id = $matches[2];
        }
        //Web-money
        if ($nameProvider == "webmoney") {
            preg_match("/^(https:\/\/)?([^\/]+)?(.wmkeeper.com)/", $json['identity'], $matches);
            $id = $matches[2];
        }
        //Rambler
        if ($nameProvider == "rambler") {
            preg_match("/^(https:\/\/id\.rambler\.ru\/users\/)?([^\/]+)/", $json['identity'], $matches);
            $id = $matches[2];
        }
        //Flickr
        if ($nameProvider == "flickr") {
            preg_match("/^(https:\/\/me\.yahoo\.com\/a\/)?([^\/]+)/", $json['identity'], $matches);
            $id = $matches[2];
        }

        return $id;
    }

    private function login($json) {
        $passwd = $this->generatePasswd($json);
        $nameProvider = $this->getNameProvider($json);
        $id = $this->getId($json);
        
        
        $mainframe = mosMainFrame::getInstance();

        $remember = (bool)mosGetParam($_REQUEST, 'remember', false);
        $username = $id . ':' . $nameProvider;

        $error = $mainframe->login($username, $passwd, $remember);

        //Отправляем пользователя на ту страницу где он был
        mosRedirect($_COOKIE['returnurl']);
    }

    private function register($json) {

        josSpoofCheck( NULL, NULL , 'get');

        global $mosConfig_useractivation;
        $mainframe = mosMainFrame::getInstance();
	$database = $mainframe->getDBO();
	$acl = &gacl::getInstance();
        
        $passwd = $this->generatePasswd($json);

	$salt = mosMakePassword(16);
	$crypt = md5($passwd.$salt);
	$passwd = $crypt.':'.$salt;

        $nameProvider = $this->getNameProvider($json);
        $id = $this->getId($json);

        $user = new mosUser($database);
        $data = array();
        
        $usertype = 'Registered';

        //e-mail
        $email = $json['email'];
        if (empty($json['email'])) {
            //VKontakte
            if ($json['provider'] == 'http://vkontakte.ru/') {
                $email = $id . '@vkontakte.ru';
            }
            //Twitter.ru
            if ($json['provider'] == 'http://twitter.com/') {
                $email = $id . '@twitter.com';
            }
            //Yandex.ru
            if ($json['provider'] == 'http://openid.yandex.ru/server/') {
                $email = $id . '@yandex.ru';
            }
            //Mail.ru
            if ($json['provider'] == 'http://mail.ru/') {
                $email = $id . '@mail.ru';
            }
            //MyOpenId
            if ($json['provider'] == 'http://www.myopenid.com/server') {
                $email = $id . '@myopenid.com';
            }
            //Web-money
            preg_match("/^(https:\/\/)?([^\/]+)?(wmkeeper.com)/", $json['identity'], $matches);
            $webmoneyProvider = $matches[3];

            if ($webmoneyProvider == 'wmkeeper.com') {
                $email = $id . '@webmoney.com';
            }
            //Rambler
            if ($json['provider'] == 'http://id.rambler.ru/script/openid.cgi') {
                $email = $id . '@rambler.ru';
            }
        }

        //name
        $name = $json['name']['full_name'];
        if ($name == null) {
            $name = $json['name']['first_name'] . ' ' . $json['name']['last_name'];
        }

        //name2
        if ($name == null or $name == ' ') {
            $name = $id;
        }

        $data['name'] = $name;
        $data['username'] = $id . ':' . $nameProvider;
        $data['email'] = $email;
        $data['gid'] = $acl->get_group_id($usertype, 'ARO');
        $data['password'] = $passwd;
        $data['password2'] = $passwd;
        $data['sendEmail'] = 1;
        $data['usertype'] = $usertype;

        $useractivation = $mosConfig_useractivation;
        if ($useractivation == 1) {
            $data['block'] = 1;
            $data['activation'] = mosMakePassword();
        } else {
            $data['block'] = 0;
        }
        
        if (!$user->bind($data)) {
            echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
            return false;
        }

        if (!$user->store()) {
            echo "<script> alert('".$row->getError()."'); window.history.go(-1); </script>\n";
            return false;
        }
    }

    public function auth($json) {
        $nameProvider = $this->getNameProvider($json);
        $id = $this->getId($json);

        if (@$json['error_type'] != null) {
            mosRedirect('index.php');
        } else {
            $db = database::getInstance();
            $query = 'SELECT *'
                    . ' FROM `#__users`'
                    . ' WHERE `username` = \'' . $id . ':' . $nameProvider . '\'';
            $user = $db->setQuery($query)->loadObjectList();

            if (count($user)>0) {
                //Авторизуемся
                $this->login($json);
            } else {
                //Регистрируемся
                $this->register($json);
                $this->login($json);
            }
        }
    }

}

?>