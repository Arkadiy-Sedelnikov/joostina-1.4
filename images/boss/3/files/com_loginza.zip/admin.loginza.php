<?php

/**
 * @package Joostina BOSS
 * @copyright Авторские права (C) 2008-2010 Joostina team. Все права защищены.
 * @license Лицензия http://www.gnu.org/licenses/gpl-2.0.htm GNU/GPL, или help/license.php
 * Joostina BOSS - свободное программное обеспечение распространяемое по условиям лицензии GNU/GPL
 * Joostina BOSS основан на разработках Jdirectory от Thomas Papin
 */
defined('_VALID_MOS') or die();

// ensure user has access to this function
if (!($acl->acl_check('administration', 'edit', 'users', $my->usertype, 'components', 'all') | $acl->acl_check('administration', 'edit', 'users', $my->usertype, 'components', 'com_loginza'))) {
    mosRedirect('index2.php', _NOT_AUTH);
}

$mainframe = mosMainFrame::getInstance();
$mainframe->addCSS(JPATH_SITE . '/administrator/components/com_loginza/assets/css/style.css');

require_once( $mainframe->getPath('admin_html') );
require_once( $mainframe->getPath('class') );

//Подключаем язык
global $mosConfig_lang;
$lang = ($mosConfig_lang == '') ? 'russian' : $mosConfig_lang;
require_once (JPATH_BASE . DS . 'administrator' . DS . 'components' . DS . 'com_loginza' . DS . 'languages' . DS . $lang . '.php');

$act = mosGetParam($_REQUEST, 'act', '');
$task = mosGetParam($_REQUEST, 'task', '');

switch ($act) {

    case "configuration":
        switch ($task) {
            case "save":
                saveConfiguration();
                break;

            default:
                configuration();
                break;
        }
        break;

    default:
        configuration();
        break;
}

function configuration() {

    $database = database::getInstance();
    $q = "SELECT `name`, `value` FROM #__config WHERE `group` = 'com_loginza'";
    $params = $database->setQuery($q)->loadObjectList('name');

    $secretkey = (!@$params['secret']->value) ? '' : $params['secret']->value;
    $vidgetid = (!@$params['vidgetid']->value) ? '' : $params['vidgetid']->value;

    HTML_loginza::configuration($secretkey, $vidgetid);
}

function saveConfiguration() {
    $database = database::getInstance();


    $q = "DELETE FROM #__config WHERE `group` = 'com_loginza'";
    $database->setQuery($q)->query();

    $datas = array();
    $datas[0]['value'] = mosGetParam($_REQUEST, 'secret', '');
    $datas[0]['name'] = 'secret';
    $datas[1]['value'] = mosGetParam($_REQUEST, 'vidgetid', '');
    $datas[1]['name'] = 'vidgetid';
    
    foreach($datas as $data){
        $row = new loginzaAdmin();
        // bind it to the table
        if (!$row->bind($data)) {
            echo "<script> alert('" . $row->getError() . "'); window.history.go(-1); </script>\n";
            exit();
        }

        // store it in the db
        if (!$row->store()) {
            echo "<script> alert('" . $row->getError() . "'); window.history.go(-1); </script>\n";
            exit();
        }
    }
    $link = "index2.php?option=com_loginza";
    mosRedirect($link, LOGINZA_CONFIGURATION_SAVED);
}

?>